# Hướng dẫn

Tiếp tục từ bài profile1...\
Nâng cấp trang web giới thiệu bản thân đã tạo ở profile1 bằng cách sử dụng CSS để trang web trở nên đẹp mắt.\
Trang cần có:
- Thay đổi font chữ, màu sắc, khoảng cách.
- Bo tròn ảnh đại diện và căn chỉnh bố cục.
- Trang trí danh sách sở thích và mục tiêu.

Các thuộc tính CSS nên áp dụng:

- `font-family`: Chọn font chữ dễ đọc (ví dụ: Arial, sans-serif).
- `color` & `background-color`: Màu chữ và màu nền.
- `text-align`: Căn giữa tiêu đề (center).
- `border-radius`: Bo tròn ảnh đại diện (dùng 50% để tạo ảnh hình tròn).
- `margin` & `padding`: Điều chỉnh khoảng cách giữa các phần tử.
- `max-width`: Giới hạn chiều rộng khung nội dung giúp dễ nhìn hơn trên màn hình lớn.

## Mở rộng

1. Tạo hiệu ứng phóng to nhẹ hoặc xoay ảnh khi người dùng di chuột qua ảnh đại diện.
2. Chuyển từng sở thích hoặc mục tiêu thành dạng hộp có màu nền riêng biệt.
3. Tạo cấu trúc màu tối cho trang web.