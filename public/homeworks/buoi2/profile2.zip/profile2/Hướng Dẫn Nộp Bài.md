# Hướng Dẫn Nộp Bài

## Các bước
1. Nén thư mục này thành một file zip hoặc rar.
2. Mở hệ thống nộp bài tại: https://nqdroboticsclub.github.io/12-tuan-training/#/upload.
3. Điền thông tin:
    - Họ và tên: để đầy đủ họ và tên, ghi có dấu và có in hoa các ký tự đầu.
    - Lớp: lớp định dạng kiểu 10T1 hay 11TH, không định dạng kiểu lớp, khóa(T1k17, T2k18, ...)
    - Buổi: là buổi của bài này("buổi 2")
    - Bài: là tên thư mục (profile2)
4. Kéo thả/tìm thư mục/đăng lên google drive và gửi link.
5. Ấn nộp bài.
6. Đợi, có thể đợi tới 3-5p, nếu đợi lâu quá có thể nộp riêng cho tui.

## Ghi chú khác
Đừng xóa thư mục này sau khi nộp, sẽ dùng lại