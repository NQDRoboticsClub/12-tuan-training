# Hướng dẫn

Tiếp tục từ bài miniwiki1...\
Nâng cấp trang wiki đơn giản đã tạo ở bài MiniWiki 1 bằng cách sử dụng CSS\

Bạn có thể chọn:
- Thay đổi font chữ, màu sắc, khoảng cách cho toàn bộ trang.
- Trang trí bảng thông tin (`<table>`), hình ảnh (`<img>`) và liên kết (`<a>`).
- Căn chỉnh bố cục khung nội dung và các khu vực `<div>` đã chia ở bài trước.

## Yêu cầu

Trang nên có các phần sau:
- `font-family`: Chọn font chữ dễ đọc (ví dụ: Arial, sans-serif).
- `color` & `background-color`: Màu chữ và màu nền.
- `text-align`: Căn giữa tiêu đề (center).
- `border-radius`: Bo tròn ảnh đại diện (dùng 50% để tạo ảnh hình tròn).
- `margin` & `padding`: Điều chỉnh khoảng cách giữa các phần tử.
- `max-width`: Giới hạn chiều rộng khung nội dung giúp dễ nhìn hơn trên màn hình lớn.

### Mở rộng

- Chế độ tối
- Hiệu ứng di chuột