# Hướng dẫn

Tạo một trang wiki đơn giản về một chủ đề bất kỳ.

Bạn có thể chọn:

- Một quốc gia
- Một thành phố
- Một trò chơi
- Một bộ phim
- Một loài động vật
- Một môn thể thao
- Một nhân vật lịch sử
- Hoặc bất kỳ chủ đề nào bạn thích.

## Yêu cầu

Trang cần có các phần sau.

### 1. Tiêu đề

Hiển thị tên chủ đề bằng `<h1>`.

### 2. Giới thiệu

Viết một đoạn giới thiệu ngắn bằng `<p>`.

### 3. Hình ảnh

Thêm ít nhất một hình ảnh bằng `<img>`.

### 4. Nội dung

Tạo ít nhất 2 mục nội dung bằng các heading.

Ví dụ:

```text
Tên chủ đề
├── Giới thiệu
├── Đặc điểm
└── Một số thông tin
```

### 5. Danh sách

Sử dụng `<ul>` hoặc `<ol>` để liệt kê một số thông tin.

### 6. Bảng

Tạo một bảng chứa các thông tin quan trọng.

Bảng cần có:
```html
<table>
<tr>
<th>
<td>
```
### 7. Liên kết

Thêm ít nhất một liên kết đến trang web có thông tin về chủ đề.

Sử dụng `<a>`.

### 8. Định dạng văn bản

Sử dụng một số thẻ:

- `<b>`
- `<i>`
- `<u>`
- `<strong>`
- `<em>`
- `<mark>`
- `<del>`
- `<sub>`
- `<sup>`

Không cần sử dụng tất cả nếu không phù hợp với nội dung.

### Mở rộng

Thử sử dụng `<div>` để chia trang thành các khu vực.

Ví dụ:
```html
<div>
    Phần giới thiệu
</div>

<div>
    Thông tin
</div>

<div>
    Tham khảo
</div>
```
Sau đó thử sử dụng `<span>` để định dạng hoặc đánh dấu một phần nhỏ bên trong đoạn văn.