# Hướng dẫn

Viết một đoạn giới thiệu ngắn về HTML.

Trong bài, hãy thử sử dụng các thẻ định dạng văn bản sau:

| Thẻ | Công dụng |
| --- | --- |
| `<b>` | In đậm |
| `<i>` | In nghiêng |
| `<u>` | Gạch chân |
| `<strong>` | Nhấn mạnh nội dung |
| `<em>` | Nhấn mạnh bằng chữ nghiêng |
| `<mark>` | Đánh dấu nội dung |
| `<del>` | Nội dung bị xóa |
| `<sub>` | Chỉ số dưới |
| `<sup>` | Chỉ số trên |

Ví dụ:

- `H<sub>2</sub>O`
- `x<sup>2</sup>`
- `<mark>HTML</mark>`

## Mở rộng

Tạo một phần có tiêu đề "Một số ví dụ".

Trong đó viết:

- Công thức hóa học của nước.
- Một biểu thức toán học có số mũ.
- Một từ được đánh dấu.
- Một nội dung đã bị xóa.

Thử kết hợp nhiều thẻ với nhau.