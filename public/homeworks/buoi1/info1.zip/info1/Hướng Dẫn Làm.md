# Hướng dẫn

Tạo một trang HTML giới thiệu về một chủ đề mà bạn yêu thích.

Ví dụ:

- Minecraft
- Bóng đá
- Nhật Bản
- Một bộ phim
- Một món ăn
- Một nhân vật nổi tiếng
- Một trò chơi

Trang cần có:

## 1. Tiêu đề

Sử dụng các thẻ heading như `<h1>`, `<h2>`.

## 2. Đoạn văn

Sử dụng `<p>` để viết phần giới thiệu.

## 3. Hình ảnh

Sử dụng:

```html
<img src="..." alt="...">
```
## 4. Liên kết

Sử dụng:

```html
<a href="...">...</a>
```
## 5. Danh sách

Sử dụng một trong:

```html
<ul>
    <li>...</li>
</ul>
```
hoặc:

```html
<ol>
    <li>...</li>
</ol>
```
## 6. Bảng

Tạo một bảng bằng:

```html
<table>
<tr>
<th>
<td>
```
Ví dụ, bảng có thể chứa:
| Thông tin | Nội dung |
| --------- | -------- |
| Tên       | ...      |
| Thể loại | ...      |
| Năm       | ...      |

## Mở rộng:
1. Thêm nhiều hơn một hình ảnh.
2. Thêm ít nhất 2 liên kết.
3. Tạo bảng có ít nhất 3 hàng.
4. Tạo cả `<ul>` và `<ol>` trên cùng trang.
5. Thử đặt một liên kết vào bên trong một đoạn văn.