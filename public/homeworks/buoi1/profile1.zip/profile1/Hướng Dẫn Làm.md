# Hướng dẫn

Tạo một trang HTML giới thiệu bản thân.

Trang cần có:

- Họ tên bằng một tiêu đề lớn.
- Một đoạn văn giới thiệu bản thân.
- Một ảnh đại diện(hình gì cũng được)
- Lớp hiện tại.
- Danh sách ít nhất 3 sở thích.
- Có sử dụng xuống dòng ở nơi phù hợp.

Có thể sử dụng các thẻ:

- `<h1>` đến `<h6>`: tiêu đề
- `<p>`: đoạn văn
- `<img>`: ảnh
- `<br>`: xuống dòng
- `<ul>`: danh sách không đánh số
- `<ol>`: danh sách có đánh số
- `<li>`: một phần tử trong danh sách

## Mở rộng

1. Thêm một tiêu đề "Mục tiêu của tôi".
2. Viết ít nhất 2 mục tiêu.
3. Thử thay đổi danh sách sở thích từ danh sách không đánh số sang danh sách có đánh số.
4. Có thể tạo trang này mà không sử dụng `<p>` không? Hãy thử.